<?php
declare(strict_types=1);

class CFrontController
{
    public function dispatchFromRequest(): mixed
    {
        $controllerName = $this->resolveControllerName();
        $actionName = $this->resolveActionName();
        $params = $this->collectParams();

        return $this->dispatch($controllerName, $actionName, $params);
    }

    public function dispatch(string $controllerName, string $actionName, array $params = []): mixed
    {
        $controllerName = trim($controllerName);
        $actionName = trim($actionName);

        if ($controllerName === '' || $actionName === '') {
            http_response_code(404);
            return ['errore' => 'Controller non trovato.'];
        }

        $className = 'C' . $controllerName;
        $controllerFile = __DIR__ . '/' . $className . '.php';

        if (!is_file($controllerFile)) {
            http_response_code(404);
            return ['errore' => 'Controller non trovato.'];
        }

        require_once $controllerFile;

        if (!class_exists($className)) {
            http_response_code(404);
            return ['errore' => 'Controller non trovato.'];
        }

        if (!method_exists($className, $actionName)) {
            http_response_code(405);
            return ['errore' => 'Metodo non consentito.'];
        }

        $method = new ReflectionMethod($className, $actionName);
        if (!$method->isPublic()) {
            http_response_code(405);
            return ['errore' => 'Metodo non consentito.'];
        }

        $controller = new $className();
        $orderedParams = $this->orderParamsForMethod($method, $params);

        return $controller->$actionName(...$orderedParams);
    }

    private function resolveControllerName(): string
    {
        $fromGet = trim((string) ($_GET['controller'] ?? ''));
        if ($fromGet !== '') {
            return $fromGet;
        }

        $segments = $this->pathSegments();
        return $segments[0] ?? '';
    }

    private function resolveActionName(): string
    {
        $fromGet = trim((string) ($_GET['action'] ?? ''));
        if ($fromGet !== '') {
            return $fromGet;
        }

        $segments = $this->pathSegments();
        return $segments[1] ?? '';
    }

    private function collectParams(): array
    {
        $params = array_merge($_GET, $_POST);
        unset($params['controller'], $params['action']);
        return $params;
    }

    private function pathSegments(): array
    {
        $path = parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
        if (!is_string($path)) {
            return [];
        }

        return array_values(
            array_filter(
                explode('/', trim($path, '/')),
                static fn (string $segment): bool => $segment !== ''
            )
        );
    }

    private function orderParamsForMethod(ReflectionMethod $method, array $params): array
    {
        if ($params === []) {
            return [];
        }

        $allNumericKeys = array_keys($params) === range(0, count($params) - 1);
        if ($allNumericKeys) {
            return array_values($params);
        }

        $ordered = [];
        foreach ($method->getParameters() as $parameter) {
            $name = $parameter->getName();
            if (array_key_exists($name, $params)) {
                $ordered[] = $params[$name];
            } elseif ($parameter->isDefaultValueAvailable()) {
                $ordered[] = $parameter->getDefaultValue();
            }
        }

        return $ordered;
    }
}

